/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package visionneuse;

/**
 *
 * @author ZBook hp
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.File;

public class FenetreVisionneuse extends JFrame implements ActionListener {

    private JLabel imageDisplayLabel;
    private JButton openButton;
    private JFileChooser fileChooser;

    public FenetreVisionneuse() {
        super("Visionneuse d'Images");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);
        setLayout(new BorderLayout());

        imageDisplayLabel = new JLabel("", SwingConstants.CENTER);
        openButton = new JButton("Ouvrir une image");
        fileChooser = new JFileChooser();

        JPanel topPanel = new JPanel();
        topPanel.add(openButton);
        add(topPanel, BorderLayout.NORTH);
        add(new JScrollPane(imageDisplayLabel), BorderLayout.CENTER);

        openButton.addActionListener(this);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == openButton) {
            int result = fileChooser.showOpenDialog(this);
            if (result == JFileChooser.APPROVE_OPTION) {
                File selectedFile = fileChooser.getSelectedFile();
                try {
                    ImageIcon imageIcon = new ImageIcon(selectedFile.getAbsolutePath());
                    if (imageIcon.getIconWidth() == -1) {
                        throw new Exception("Le fichier sélectionné n'est pas une image valide.");
                    }
                    imageDisplayLabel.setIcon(imageIcon);
                    imageDisplayLabel.setText("");
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(this,
                        "Erreur lors du chargement de l'image : " + ex.getMessage(),
                        "Erreur",
                        JOptionPane.ERROR_MESSAGE);
                }
            }
        }
    }
}

    
    

